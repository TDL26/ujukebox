﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication1;

namespace WebApplication1.Controllers
{
    public class VenueApiController : ApiController
    {
        private jukedbEntities1 db = new jukedbEntities1();


        public IQueryable<string> GetVenues()
        {
            return db.Venues.OrderBy(c => c.VenueName).Select(c => c.VenueName);
            

        // GET api/VenueApi
        //public IQueryable<Venue>GetVenues()
        //{
            //////var venues =
            //////from n in db.Venues
            ////////where n.Club92 == 
            //////select n;
        
            //////foreach (var item in venues)
            //////{
            //////    item.VenueName.ToString();
            //////    //item.Club92.ToString();
            //////}

            //////return venues.OrderBy(c => c.VenueName);   //where Coppers == 1

           // return db.Venues.OrderBy(c => c.VenueName);
            //turn db.Venues.OrderByDescending(c => c.VenueName);
           //eturn db.Venues.OrderBy(c => c.VenueName).Select(c => c.VenueName);
        }

        // GET api/VenueApi/5
        [ResponseType(typeof(Venue))]
        public IHttpActionResult GetVenue(int id)
        {
            Venue venue = db.Venues.Find(id);
            if (venue == null)
            {
                return NotFound();
            }

            return Ok(venue);
        }

        // PUT api/VenueApi/5
        public IHttpActionResult PutVenue(int id, Venue venue)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != venue.VenueID)
            {
                return BadRequest();
            }

            db.Entry(venue).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VenueExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/VenueApi
        [ResponseType(typeof(Venue))]
        public IHttpActionResult PostVenue(Venue venue)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Venues.Add(venue);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = venue.VenueID }, venue);
        }

        // DELETE api/VenueApi/5
        [ResponseType(typeof(Venue))]
        public IHttpActionResult DeleteVenue(int id)
        {
            Venue venue = db.Venues.Find(id);
            if (venue == null)
            {
                return NotFound();
            }

            db.Venues.Remove(venue);
            db.SaveChanges();

            return Ok(venue);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool VenueExists(int id)
        {
            return db.Venues.Count(e => e.VenueID == id) > 0;
        }
    }
}