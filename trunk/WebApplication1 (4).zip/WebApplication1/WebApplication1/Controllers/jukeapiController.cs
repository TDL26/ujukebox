﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication1;

namespace WebApplication1.Controllers
{
    public class jukeapiController : ApiController
    {
        private jukedbEntities1 db = new jukedbEntities1();

        // GET api/jukeapi
       public IQueryable<Track> GetTracks()

        //public IQueryable<string> GetTracks()
        {
            return db.Tracks.OrderByDescending(c => c.TrackID);
            //foreach (var item in db.Tracks)
            //{
            //    string PopBar = item.PopBar.ToString();
            //}
           // return db.Tracks.OrderByDescending(c => c.PopBar).Select(c => c.PopBar).ToList();
            //return db.Tracks.OrderBy(c => c.PopBar).Select(c => c.PopBar);


           // return db.Tracks.OrderByDescending(c => c.PopBar.ToString()).Select(c => c.PopBar.ToString());

           // var item = 
            
            //return db.Tracks.OrderBy(c => c.PopBar).Select(c => c.PopBar);


        }

        // GET api/jukeapi/5
        [ResponseType(typeof(Track))]
        public IHttpActionResult GetTrack(int id)
        {
            Track track = db.Tracks.Find(id);
            if (track == null)
            {
                return NotFound();
            }

            return Ok(track);
        }

        // PUT api/jukeapi/5
        public IHttpActionResult PutTrack(int id, Track track)
        {
           ////////Track track = new Track();
           //////// track.TrackID = newtrack.TrackID;
           //////// track.Title = newtrack.Title;
           //////// track.Artist = newtrack.Artist;
            
           //////// var data = 
           //////// from n in db.Tracks
           //////// select n;
                      
           //////// foreach (var item in data)
           //////// {
           ////////     track.PartyClub = item.PartyClub;
           ////////     track.PopBar = item.PopBar;
           ////////     track.RockBar = item.RockBar;
           ////////     track.DanceClub = item.DanceClub;          
           //////// }
            
           
           //////// if (newtrack.Venue == "PopBar")
           //////// {
           ////////     track.PopBar = newtrack.Vote;
           //////// }
           //////// if (newtrack.Venue == "RockBar")
           //////// {
           ////////     track.RockBar = newtrack.Vote;
           //////// }
           //////// if (newtrack.Venue == "PartyClub")
           //////// {
           ////////     track.PartyClub = newtrack.Vote;
           //////// }
           //////// if (newtrack.Venue == "DanceClub")
           //////// {
           ////////     track.DanceClub = newtrack.Vote;
           //////// }

            
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != track.TrackID)
            {
                return BadRequest();
            }

            db.Entry(track).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TrackExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/jukeapi
        [ResponseType(typeof(Track))]
        public IHttpActionResult PostTrack(Track track)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Tracks.Add(track);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = track.TrackID }, track);
        }

        // DELETE api/jukeapi/5
        [ResponseType(typeof(Track))]
        public IHttpActionResult DeleteTrack(int id)
        {
            Track track = db.Tracks.Find(id);
            if (track == null)
            {
                return NotFound();
            }

            db.Tracks.Remove(track);
            db.SaveChanges();

            return Ok(track);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TrackExists(int id)
        {
            return db.Tracks.Count(e => e.TrackID == id) > 0;
        }
    }
}