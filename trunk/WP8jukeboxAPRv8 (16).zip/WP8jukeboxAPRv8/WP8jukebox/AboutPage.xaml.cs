﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.Phone.Tasks;

namespace WP8jukebox
{
    public partial class AboutPage : PhoneApplicationPage
    {
        public AboutPage()
        {
            InitializeComponent();
            this.textblock1.Text = "\r\r\r\r\r\nUJukebox\r\nVersion 1.0\r\n\r\nBuilt by Audioweb26\r\n\r\nContact audioweb26@gmail.com";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            WebBrowserTask task = new WebBrowserTask();
            task.Uri = new Uri("http://www.windowsphone.com/en-ie/store", UriKind.Absolute);
            task.Show();
        }
    }
}