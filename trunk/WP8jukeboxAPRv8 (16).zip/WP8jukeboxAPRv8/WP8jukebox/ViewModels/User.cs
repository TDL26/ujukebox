﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WP8jukebox.ViewModels
{
    class User
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string  UserEMail { get; set; }
        public string UserPassword { get; set; }
        public string UserVenue { get; set; }
        public string UserVerified { get; set; }
    }
}
