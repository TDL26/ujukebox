﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WP8jukebox.ViewModels
{
    public class AVenue
    {
        public static string TheVenue { get; set; }
    }
}
