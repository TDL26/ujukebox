﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using WP8jukebox.ViewModels;

namespace WP8jukebox
{
    public partial class LoginPage : PhoneApplicationPage
    {
        string getVenue = "";
        string name = "";
        string password = "";
        //string venue = "";
        //string verified = "";
        public static string venueBox { get; set; }
        

        public LoginPage()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            getVenue = NavigationContext.QueryString["getVenue"];
            venueBox = getVenue;
            textBox1.Text = venueBox;
        }
        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //go to new account page
            // button click navigates to chart page and forwards getVenue
            NavigationService.Navigate(new Uri("/UserPage.xaml?getVenue=" + getVenue, UriKind.Relative));
                
        }

        private void NameBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            name = NameBox.Text;
        }

        private void PassBox_TextChanged(object sender, RoutedEventArgs e)
        {
            password = PassBox.Password;
        }

        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                //login
                // base URL for API Controller i.e. RESTFul service
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri("http://jukebox.azurewebsites.net/");

                // add an Accept header for JSON
                client.DefaultRequestHeaders.
                Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = await client.GetAsync("api/user");
                var users = await response.Content.ReadAsAsync<IEnumerable<User>>();

                foreach (var item in users)
                {
                    string name1 = item.UserName.ToUpper().Replace(" ", string.Empty);
                    string name2 = name.ToUpper().Replace(" ", string.Empty);
                    string verified = item.UserVerified;
                    string venue = item.UserVenue;

                    //check names match
                    if (name1 == name2)
                    {
                        if (item.UserPassword == password)
                        {
                            if (verified == "true")
                            {
                                //Set venue to users AdminPage rights
                                getVenue = venue;
                                //match ok login
                                // button click navigates to chart page and forwards getVenue
                                NavigationService.Navigate(new Uri("/AdminPage.xaml?getVenue=" + getVenue, UriKind.Relative));
                            }
                            
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBoxResult result =
                MessageBox.Show("You seem to be having trouble connecting to the Network!\n\nCheck that you have a network connection.\n\nTry Again?",
                "Network Error!", MessageBoxButton.OKCancel);

                    if (result == MessageBoxResult.OK)
                    {
                        NavigationService.Navigate(new Uri("/LoginPage.xaml?getVenue=" + getVenue, UriKind.Relative));
                    }
                    else
                    {
                        MessageBox.Show("Press the Back button to Exit the application.");
                    }
                    //throw;
                
            }
            
            

            //failed login
            NavigationService.Navigate(new Uri("/LoginFailPage.xaml?getVenue=" + getVenue, UriKind.Relative));
                 
        }

       
   }
}