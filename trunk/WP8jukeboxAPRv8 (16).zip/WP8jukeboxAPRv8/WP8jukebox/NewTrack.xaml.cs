﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace WP8jukebox
{
    public partial class NewTrack : PhoneApplicationPage
    {
        string getVenue = "";
        public static string venueBox { get; set; }
        string popbar = "0";
        string partyclub = "0";
        string rockbar = "0";
        string danceclub = "0";
        string alternativebar = "0";
        string popclub = "0";
        string rnbclub = "0";

        public NewTrack()
        {
            InitializeComponent();
        }
           
        // Load data for the ViewModel Items
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            getVenue = NavigationContext.QueryString["getVenue"];
            venueBox = getVenue;
            textBox1.Text = venueBox;

            Text5.Visibility = Visibility.Visible;
            Text6.Visibility = Visibility.Collapsed;
        }
         
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string boxtitle;
            boxtitle = titlebox.Text;
        }

        private async void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Text6.Visibility = Visibility.Visible;
            Text5.Visibility = Visibility.Collapsed;
            
            string title = titlebox.Text;    //tr.LineOne;
            string artist = artistbox.Text;
            string genre = genrebox.Text;

            string venue = getVenue.Replace(" ", string.Empty);

            if (venue == "PopBar")
            {
                popbar = "1";
            }
            if (venue == "PartyClub")
            {
                partyclub = "1";
            }
            if (venue == "RockBar")
            {
                rockbar = "1";
            }
            if (venue == "DanceClub")
            {
                danceclub = "1";
            }
            if (venue == "AlternativeBar")
            {
                alternativebar ="1";
            }
            if (venue == "PopClub")
            {
                popclub = "1";
            }
            if (venue == "RnbClub")
            {
                rnbclub = "1";
            }

            // base URL for API Controller i.e. RESTFul service
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://jukebox.azurewebsites.net/");

            // add an Accept header for JSON
            client.DefaultRequestHeaders.
            Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage response = await client.GetAsync("api/jukeapi");

            Track newListing = new Track { TrackID = "8", Title = title, Artist = artist, Genre = genre, PopBar = popbar, PartyClub = partyclub, RockBar = rockbar, DanceClub = danceclub, AlternativeBar = alternativebar, PopClub = popclub, RnbClub = rnbclub, Admin = "1" };

            // update by Put to /api/ujukeapi a listing serialised in request body
            //the +id is added to the url to address the correct row in the db
            response = await client.PostAsJsonAsync("api/jukeapi/", newListing);

            //back to playlist page            
            NavigationService.Navigate(new Uri("/AdminPage.xaml" + "?getVenue=" + getVenue + "&fromDetails=true" + "&fromPlaylist=true" + "&venue" + venue, UriKind.Relative));

            //delay the page navigation so user can see vote acknowledgement                      
            Thread.Sleep(1000);
         }
    }
}