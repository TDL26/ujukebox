﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace WP8jukebox
{
    public partial class AdminPage : PhoneApplicationPage
    {
         string getVenue = "";
         string fromAdmin = "fromAdmin";
         string fromEdit = "fromEdit";
         string fromFull = "fromFull";
         string fromDelete = "";
         public static string venueBox { get; set; }
       
        public AdminPage()
        {
            InitializeComponent();
        }

        // Load data for the ViewModel Items
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            getVenue = NavigationContext.QueryString["getVenue"];
            venueBox = getVenue;
            textBox1.Text = venueBox;
            NavigationContext.QueryString.TryGetValue("fromDelete", out fromDelete);

            if (getVenue == "Admin")
            {
                textadd.Visibility = Visibility.Collapsed;
                textfull.Visibility = Visibility.Collapsed;
            }
            
        }

      
       //new track
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // button click navigates to chart page and forwards getVenue
            NavigationService.Navigate(new Uri("/NewTrack.xaml?getVenue=" + getVenue + "&fromAdmin=" + fromAdmin, UriKind.Relative));
        }

       //delete button
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            // button click navigates to chart page and forwards getVenue
            NavigationService.Navigate(new Uri("/PlaylistPage.xaml?getVenue=" + getVenue + "&fromAdmin=" + fromAdmin, UriKind.Relative));
        }

        //edit button
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            // button click navigates to chart page and forwards getVenue
            NavigationService.Navigate(new Uri("/PlaylistPage.xaml?getVenue=" + getVenue + "&fromEdit=" + fromEdit, UriKind.Relative));
        }

        //full track list
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            // button click navigates to chart page and forwards getVenue
            NavigationService.Navigate(new Uri("/PlaylistPage.xaml?getVenue=" + getVenue +"&fromFull=" + fromFull, UriKind.Relative));
        }

    }
}