﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.Phone.Tasks;
using WP8jukebox.ViewModels;

namespace WP8jukebox
{
    public partial class UserPage : PhoneApplicationPage
    {
        string getVenue = "";
        string name;
        string eMail;
        string password1 = "";
        string password2 = "";
        public static string venueBox { get; set; }

        public UserPage()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            getVenue = NavigationContext.QueryString["getVenue"];
            venueBox = getVenue;
            textBox1.Text = venueBox;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            eMail = EMailBox.Text;
        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            name = NameBox.Text;
        }

        private void Passbox1_PasswordChanged(object sender, RoutedEventArgs e)
        {
            password1 = Passbox1.Password;
        }

        private void Passbox2_PasswordChanged(object sender, RoutedEventArgs e)
        {
            password2 = Passbox2.Password;
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            if (password1 == password2)
            {
                string s = "[a-z0-9A-z]@[a-zA-z0-9 ]*[.]";
                string s1 = EMailBox.Text.ToString();
                Match aa = Regex.Match(s1, s);
                if (aa.Success)
                {
                    try
                    {
                        MessageBoxResult result =
                         MessageBox.Show("Press Submit to send your details.\n\nSign up then requires you to submit your:\nName and Email\ninformation to audioweb26@gmail.com\n\nWhen you are confirmed as an administrator you will be added to a database.\n\nYou will then be able to login.\n\n",
                        "", MessageBoxButton.OKCancel);

                        if (result == MessageBoxResult.OK)
                        {
                            // base URL for API Controller i.e. RESTFul service
                            HttpClient client = new HttpClient();
                            client.BaseAddress = new Uri("http://jukebox.azurewebsites.net/");

                            // add an Accept header for JSON
                            client.DefaultRequestHeaders.
                            Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                            HttpResponseMessage response = await client.GetAsync("api/user");

                            User newListing = new User { UserID = 0, UserName = name, UserPassword = password1, UserEMail = eMail };

                            // update by Put to /api/ujukeapi a listing serialised in request body
                            //the +id is added to the url to address the correct row in the db
                            response = await client.PostAsJsonAsync("api/user/", newListing);

                            if (response.IsSuccessStatusCode)
                            {
                                // button click navigates to chart page and forwards getVenue
                                NavigationService.Navigate(new Uri("/LoginPage.xaml?getVenue=" + getVenue, UriKind.Relative));

                                //delay the page navigation so user can see vote acknowledgement                      
                                //Thread.Sleep(1000);
                            }

                            else
                            {
                                throw new Exception();
                            }
                            //NavigationService.Navigate(new Uri("/sendmail.xaml?getVenue=" + getVenue, UriKind.Relative));
                        }
                        else
                        {
                            MessageBox.Show("Press the Back button to Exit the application.");
                        }


                    }
                    catch (Exception)
                    {
                        MessageBoxResult result2 =
                        MessageBox.Show("You seem to be having trouble connecting to the Network!\n\nCheck that you have a network connection.\n\nTry Again?",
                        "Network Error!", MessageBoxButton.OKCancel);

                        if (result2 == MessageBoxResult.OK)
                        {
                            NavigationService.Navigate(new Uri("/UserPage.xaml?getVenue=" + getVenue, UriKind.Relative));
                        }
                        else
                        {
                            MessageBox.Show("Press the Back button to Exit the application.");
                        }
                        //throw;
                    }
                    
                }
                else
                {
                    MessageBox.Show("EMail is not Valid");
                }
                
                
                
            }
            else
            {
                MessageBox.Show("Passwords do not match: Try Again");
            }

        }

        //TODO auto send email to admin
        //private void Button_Click2(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        ////email sent to audioweb admin to add user to database for admin rights to the venue
        //        EmailComposeTask emailComposeTask = new EmailComposeTask();
        //        emailComposeTask.Subject = "Add User to Database with Admin rights";
        //        emailComposeTask.Body = "Add User: Venue: " + getVenue + " Name: " + name + " EMail: " + eMail + " Password: " + password1;
        //        emailComposeTask.To = "audioweb26@gmail.com";
        //        emailComposeTask.Cc = "";
        //        emailComposeTask.Bcc = "";
        //        emailComposeTask.Show();
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }

        //}





    }
}