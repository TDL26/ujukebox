﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WP8jukebox
{
    class Club
    {

        public string ClubName { get; set; }
        public string ClubGenre { get; set; }
    }
}
