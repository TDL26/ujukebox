﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace WP8jukebox
{
    public partial class AdminPage : PhoneApplicationPage
    {
         string getVenue = "";
         string fromAdmin = "fromAdmin";
         string fromEdit = "fromEdit";
         public static string venueBox { get; set; }
       
        public AdminPage()
        {
            InitializeComponent();
            // Set the data context of the LongListSelector control to the sample data
           // DataContext = App.ViewModel;
        }

        // Load data for the ViewModel Items
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            getVenue = NavigationContext.QueryString["getVenue"];
            venueBox = getVenue;
            textBox1.Text = venueBox;
            //App.ViewModel = null;
        }

        

        //private void setDataContext()
        //{
        //    ContentPanel.DataContext = getVenue;
        //}
  
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // button click navigates to chart page and forwards getVenue
            NavigationService.Navigate(new Uri("/NewTrack.xaml?getVenue=" + getVenue + "&fromAdmin=" + fromAdmin, UriKind.Relative));
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            // button click navigates to chart page and forwards getVenue
            NavigationService.Navigate(new Uri("/PlaylistPage.xaml?getVenue=" + getVenue + "&fromAdmin="+ fromAdmin, UriKind.Relative));
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            // button click navigates to chart page and forwards getVenue
            NavigationService.Navigate(new Uri("/PlaylistPage.xaml?getVenue=" + getVenue + "&fromEdit="+ fromEdit, UriKind.Relative));
        }
    }
}