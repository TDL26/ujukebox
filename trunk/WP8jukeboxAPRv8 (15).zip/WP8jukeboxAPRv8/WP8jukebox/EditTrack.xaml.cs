﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using WP8jukebox.ViewModels;

namespace WP8jukebox
{
    public partial class EditTrack : PhoneApplicationPage
    {
        string getVenue = "";
        public static string venueBox { get; set; }
        public string venue = "";

        //new viewmodel property to display page by vote order
        public ItemViewModel tr;

        //get real index of model
        string getreal = "";
        string fromEdit = "";

        public EditTrack()
        {
            InitializeComponent();
        }
        
        // Load data for the ViewModel Items
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            getVenue = NavigationContext.QueryString["getVenue"];
            venueBox = getVenue;
            textBox1.Text = venueBox;
        
            Text5.Visibility = Visibility.Visible;
            Text6.Visibility = Visibility.Collapsed;
          
            string selectedIndex = "";

            getVenue = NavigationContext.QueryString["getVenue"];
            venueBox = getVenue;
            textBox1.Text = venueBox;

            //NavigationContext.QueryString.TryGetValue("fromAdmin", out fromAdmin);
            NavigationContext.QueryString.TryGetValue("fromEdit", out fromEdit);

            if (fromEdit == "fromEdit")
            {
               
            }

            //not from chart load Items3
            if (DataContext == null)
            {
                if (NavigationContext.QueryString.TryGetValue("selectedItem", out selectedIndex))
                {
                    int index = int.Parse(selectedIndex);
                    DataContext = App.ViewModel.Items3[index];
                    getreal = App.ViewModel.Items3[index].RealID;
                }
            }
        }
        
        //Edit track
        private async void Button_Click_3(object sender, RoutedEventArgs e)
        {
            string titletext = titlebox.Text;
            string artisttext = artistbox.Text;
            string genretext = genrebox.Text;
            string votetext = votebox.Text;
            
            Text6.Visibility = Visibility.Visible;
            Text5.Visibility = Visibility.Collapsed;
            
            App.ViewModel = null;

            ItemViewModel tr = (ItemViewModel)this.DataContext;

            //get the values to be sent to db to facilitate update PUT to db
            int id = Convert.ToInt32(getreal);
            string title = titlebox.Text;    //tr.LineOne;
            string artist = artistbox.Text;
            string genre = genrebox.Text;
            int venuevote = Convert.ToInt32(tr.LineFour);
            int popbar = Convert.ToInt32(tr.LineSix);
            int partyclub = Convert.ToInt32(tr.LineSeven);
            int rockbar = Convert.ToInt32(tr.LineEight);
            int danceclub = Convert.ToInt32(tr.LineNine);
            int alternativebar = Convert.ToInt32(tr.LineTen);
            int popclub = Convert.ToInt32(tr.LineEleven);
            int rnbclub = Convert.ToInt32(tr.LineTwelve);
                                                         
            venue = getVenue.Replace(" ", string.Empty);

            if (venue == "PopBar")
            {
                popbar = Convert.ToInt32(votetext);
            }
            if (venue == "PartyClub")
            {
                partyclub = Convert.ToInt32(votetext);
            }
            if (venue == "RockBar")
            {
                rockbar = Convert.ToInt32(votetext);
            }
            if (venue == "DanceClub")
            {
                danceclub = Convert.ToInt32(votetext);
            }

            if (venue == "AlternativeBar")
            {
                alternativebar++;
            }
            if (venue == "PopClub")
            {
                popclub++;
            }
            if (venue == "RnbClub")
            {
                rnbclub++;
            }

            // base URL for API Controller i.e. RESTFul service
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://jukebox.azurewebsites.net/");

            // add an Accept header for JSON
            client.DefaultRequestHeaders.
            Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage response = await client.GetAsync("api/jukeapi");

            Track newListing = new Track { TrackID = getreal, Title = title, Artist = artist, Genre = genre, PopBar = popbar.ToString(), PartyClub = partyclub.ToString(), RockBar = rockbar.ToString(), DanceClub = danceclub.ToString(), AlternativeBar = alternativebar.ToString(), PopClub = popclub.ToString(), RnbClub = rnbclub.ToString() };

            // update by Put to /api/ujukeapi a listing serialised in request body
            //the +id is added to the url to address the correct row in the db
            response = await client.PutAsJsonAsync("api/jukeapi/" +id, newListing);

            //if PUT fails
            if (!response.IsSuccessStatusCode)
            {
                //TODO
            }

            //back to playlist page            
            NavigationService.Navigate(new Uri("/AdminPage.xaml" + "?getVenue=" + getVenue + "&fromDetails=true" + "&fromPlaylist=true" + "&venue" + venue, UriKind.Relative));

            //delay the page navigation so user can see vote acknowledgement                      
            Thread.Sleep(1000);
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}